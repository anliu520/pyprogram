#anliu
if 1:
    print("s")
else:
    print("f")