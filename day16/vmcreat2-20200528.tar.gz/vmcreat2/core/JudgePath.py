#anliu
import os,logging.config
import configparser
configer = configparser.ConfigParser()
configer.read(os.path.join("/opt/vmcreat2/conf","vm_config.conf"))
print(configer.get("conf","src_conf_path"))

#from conf import vm_config
from conf import vm_config
#print(vm_config.conf["src_conf_path"])


logging.config.fileConfig(os.path.join("/opt/vmcreat2/conf","logging.conf"))
#print(os.path.join("/opt/vmcreat2/conf","logging.conf"))
logger = logging.getLogger("simpleExample")
#logger.error("xxxxxxx")




def judge_path():
    if os.path.isdir(vm_config.conf["src_conf_path"]):
        logger.debug("%s 目录存在..."%vm_config.conf["src_conf_path"])
        #print("%s目录存在..."%vm_config.conf["src_conf_path"])
        flag = 1
    else:
        logger.error("%s目录bu存在..."%vm_config.conf["src_conf_path"])
        #print("%s目录bu存在..."%vm_config.conf["src_conf_path"])
        flag = 0
    if os.path.isdir(vm_config.conf["det_conf_path"]):
        #print("%s目录存在..."%vm_config.conf["det_conf_path"])
        flag = 1
    else:
        #print("%s目录bu存在..." % vm_config.conf["src_conf_path"])
        flag = 0

    return flag