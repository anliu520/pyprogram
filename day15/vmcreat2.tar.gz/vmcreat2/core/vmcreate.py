#anliu
'''
 the script is used created vm .
'''

import shutil,os,sys
from xml.etree import ElementTree as ET
import uuid

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from conf import vm_config

print(vm_config.conf["src_conf_path"])


def copy_vm_conf(src_name,det_name):
    #shutil.copyfile(src_conf_path + "/" + src_name,det_conf_path +"/"+det_name)
    shutil.copyfile(os.path.join(vm_config.conf["src_conf_path"],src_name + ".xml"),os.path.join(vm_config.conf["det_conf_path"],det_name + ".xml"))

#copy_vm_conf("linux","test02")

def copy_vm_image(src_name,det_name):
    shutil.copyfile(os.path.join(vm_config.image["src_image_path"],src_name + ".img"),os.path.join(vm_config.image["det_image_path"],det_name + ".img"))

#copy_vm_image("linux","test02")

#def mod_vm_conf(det_name,memory_max,memory_curr,vcpu_max,vcpu_curr,vnc_port):

def mod_vm_conf(message):

    tree = ET.parse(os.path.join(vm_config.conf["det_conf_path"],message["vm_name"] + ".xml"))
    root = tree.getroot()

    for node1 in root.iter("name"):
        print(node1.tag,node1.text)
        node1.text = message["vm_name"]

    for node2 in root.iter("uuid"):
        print(node2.tag,node2.text)
        #print(type(uuid.uuid1()))
        node2.text = str(uuid.uuid1())

    for node3 in root.iter("memory"):
        print(node3.tag,node3.text)
        #print(type(memory_max))
        node3.text = str(message["vm_mem_max"])

    for node4 in root.iter("currentMemory"):
        #print(node4.tag,node4.text)
        node4.text = str(message["vm_mem_curr"])

    for node5 in root.iter("vcpu"):
        #print(node5.tag,node5.text,node5.attrib)
        #print(type(vcpu_curr))
        node5.text = str(message["vm_cpu_max"])
        node5.attrib["current"] = str(message["vm_cpu_curr"])

    for node6 in root.iter("source"):
        #print(node6.attrib)
        try:
            print(node6.attrib["file"])
            node6.attrib["file"] = os.path.join(vm_config.image["det_image_path"],message["vm_name"] + ".img")

        except KeyError as key:
            pass

    for node7 in root.iter("graphics"):
        print(node7.tag,node7.text,node7.attrib)
        node7.attrib["port"] = message["vm_vnc_port"]

    tree.write(os.path.join(vm_config.conf["det_conf_path"],message["vm_name"] + ".xml"))

#mod_vm_conf("test02",2048000,3096000,2,1,"5988")


def define_vm(det_mane):
    os.chdir(vm_config.conf["det_conf_path"])
    os.system("virsh define %s" %det_mane + ".xml")
    os.system("virsh start %s" %det_mane)

#define_vm("test02")





