#anliu
'''
main
'''
import os,sys,json
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from conf import vm_config
from core import vmcreate

message = {
    "vm_name":None,
    "vm_type":None,
    "vm_cpu_max":None,
    "vm_cpu_curr":None,
    "vm_mem_max":None,
    "vm_mem_curr":None,
    "vm_vnc_port":None,
}

def interactive():
    message["vm_name"] = input("vm_name:")
    message["vm_type"] = input("vm_type:")
    message["vm_cpu_max"] = input("vm_cpu_max:")
    message["vm_cpu_curr"] = input("vm_cpu_curr:")
    message["vm_mem_max"] = 1024*1024*int(input("vm_mem_max:"))
    message["vm_mem_curr"] = 1024*1024*int(input("vm_mem_curr:"))
    message["vm_vnc_port"] = input("vm_vnc_port:")

    print(message)

    with open(os.path.join(vm_config.db["db_path"],message["vm_name"]),"w",encoding="utf-8") as f1:
        json.dump(message,f1)

interactive()


def run():

    vmcreate.copy_vm_conf(message["vm_type"],message["vm_name"])
    vmcreate.copy_vm_image(message["vm_type"],message["vm_name"])
    vmcreate.mod_vm_conf(message)
    vmcreate.define_vm(message["vm_name"])

    print("this is a run ...")