
conf = {
    "src_conf_path":"/etc/libvirt/qemu",
    "det_conf_path":"/opt/vmcreat2/tmp"
}

image = {
    "src_image_path" : "/var/lib/libvirt/images/",
    "det_image_path" : "/data"
}

db = {
    "db_path":"/opt/vmcreat2/db"
}